#ifndef __util_h__
#define __util_h__

double timer();

#endif